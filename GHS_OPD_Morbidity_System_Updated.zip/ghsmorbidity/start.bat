@echo off
echo ========================================
echo   GHS OPD Morbidity System
echo   Ghana Health Service
echo ========================================
echo.
echo Starting system...
node server.js
pause
