const express = require('express');
const path    = require('path');
const fs      = require('fs');
const XLSX    = require('xlsx');

const app      = express();
const PORT     = 3456;
const DB_FILE  = path.join(__dirname, 'morbidity.json');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function loadDB() {
  if (fs.existsSync(DB_FILE)) {
    try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch(e) {}
  }
  return { visits: [], nextId: 1 };
}
function saveDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────────────────────────────────────────
const AGE_GROUPS = ['<28days','1-11mths','1-4','5-9','10-14','15-17','18-19','20-34','35-49','50-59','60-69','70+'];
const UNDER5     = ['<28days','1-11mths','1-4'];

// Full DHIMS2 morbidity structure (order from memory)
const REPORT_STRUCTURE = [
  { section: 'Communicable immunizable', rows: [
    'AFP (Polio)','Meningitis','Neo-Natal Tetanus','Pertussis (Whooping Cough)',
    'Diphteria','Measles','Yellow Fever (YF)','Tetanus','Tuberculosis'
  ]},
  { section: 'Communicable non-immunizable', rows: [
    'Uncomplicated Malaria suspected','Uncomplicated Malaria Suspected Tested',
    'Uncomplicated Malaria Tested Positive','Uncomplicated Malaria not tested but treated as malaria',
    'Uncomplicated Malaria Cases Tested Negative but Treated as Malaria',
    'Uncomplicated Malaria in Pregnancy suspected','Uncomplicated Malaria in Pregnancy Suspected Tested',
    'Uncomplicated Malaria in Pregnancy tested positive',
    'Uncomplicated Malaria in Pregnacy not tested but treated as malaria',
    'Uncomplicated Malaria in Pregnancy Tested Negative but Treated as Malaria',
    'Severe Malaria (Lab-Confirmed)','Severe Malaria (Non-Lab-Confirmed)',
    'Typhoid Fever','Suspected Cholera','Diarrhoea Diseases','Viral Hepatitis',
    'Schistosomiasis (Bilhazia)','Suspected Guinea Worm','Onchocerciasis',
    'Buruli Ulcer','Leprosy','HIV/AIDS Related conditions','Mumps',
    'Intestinal Worms','Chicken Pox',
    'Upper Respiratory Tract Infections','Pneumonia','Septiceamia'
  ]},
  { section: 'Non-Communicable Diseases', rows: [
    'Malnutrition','Obesity','Anaemia','Other Nutritional Diseases',
    'Hypertension','Cardiac Diseases','Stroke','Diabetes Mellitus',
    'Rheumatism / Other Joint Pains / Arthritis','Sickle Cell Disease','Asthma',
    'Chronic Obstructed Pulmonary Disease (COPD)',
    'Breast Cancer','Cervical Cancer','Lymphoma','Prostate Cancer',
    'Hepatocellular Carcinoma','All Other Cancers'
  ]},
  { section: 'Mental Health Conditions', rows: [
    'Schizophrenia','Acute Psychotic Disorder','Mono Symptoms Delusion','Depression',
    'Substance Abuse','Epilepsy','Autism','Mental Retardation',
    'Attention Deficit Hyperactivity Disorder','Conversion Disorders',
    'Post Traumatic Stress Syndrome','Generalized Anxiety','Other Anxiety Disorders','Neurosis'
  ]},
  { section: 'Specialized Conditions', rows: [
    'Acute Eye Infection','Cataract','Trachoma','Otitis Media','Other Acute Ear infection',
    'Dental Caries','Dental Swellings','Traumtic Conditions (Oral and Maxillofacial Region)',
    'Peridontal diseases','Cerebral Palsy','liver diseases',
    'Acute Urinary Tract Infection','Skin Diseases','Ulcer',
    'Kidney Related Diseases','Other Oral Conditions'
  ]},
  { section: 'Obstetrics & Gynaecological Conditions', rows: [
    'Gynaecological conditions','Pregnancy Related Complications','Anaemia in Pregnancy'
  ]},
  { section: 'Reproductive Tract Diseases', rows: [
    'Gonorrhoea','Genital Ulcer','Vaginal Discharge','Urethral Discharge',
    'Other diseases of the Male reproductive system',
    'Other diseases of the Female reproductive system'
  ]},
  { section: 'Injuries and Others', rows: [
    'Transport injuries (Road Traffic Accidents)',
    'Home Injuries (Home Accidents and Injuries)',
    'Occupational / Industrial Injuries','Burns','Poisoning (Occupational Poisoning)',
    'Dog bite','Human bites','Snake Bite','Sexual Abuse','Domestic Violence',
    'Pyrexia of unknown origin PUO (not Malaria)','Brought in Dead',
    'Other Animal Bites','All other Diseases'
  ]},
  { section: 'Re-Attendances and Referrals', rows: [
    'Re-Attendances','Referrals'
  ]}
];

const ALL_STANDARD_DX = REPORT_STRUCTURE.flatMap(s => s.rows);

// ─────────────────────────────────────────────────────────────────────────────
// MALARIA SMART-CODING ENGINE
// ─────────────────────────────────────────────────────────────────────────────
function getMalariaCodings(v) {
  const provisional = (v.provisional_diagnosis || '').toLowerCase();
  if (!provisional.includes('malaria')) return null;

  const isPregnant    = v.pregnant === 'Y';
  const testReq       = (v.test_requested || '').trim();
  const testResult    = (v.test_result || '').toLowerCase();
  const gender        = v.gender     || 'Male';
  const age_group     = v.age_group  || '20-34';

  const isMalariaTest = testReq !== '' &&
    testReq.toLowerCase() !== 'no test requested' &&
    (testReq.toLowerCase().includes('malaria') ||
     testReq.toLowerCase().includes('rdt') ||
     testReq.toLowerCase().includes('microscop'));

  const isPositive = testResult === 'positive';
  const isNegative = testResult === 'negative';
  const isTested   = isMalariaTest && (isPositive || isNegative);
  const notTested  = !isMalariaTest;

  const codings = [];

  if (isPregnant) {
    codings.push({ diagnosis: 'Uncomplicated Malaria in Pregnancy suspected', gender, age_group });
    if (isTested) {
      codings.push({ diagnosis: 'Uncomplicated Malaria in Pregnancy Suspected Tested', gender, age_group });
      if (isPositive) codings.push({ diagnosis: 'Uncomplicated Malaria in Pregnancy tested positive', gender, age_group });
    } else if (notTested) {
      codings.push({ diagnosis: 'Uncomplicated Malaria in Pregnacy not tested but treated as malaria', gender, age_group });
    }
  } else {
    codings.push({ diagnosis: 'Uncomplicated Malaria suspected', gender, age_group });
    if (isTested) {
      codings.push({ diagnosis: 'Uncomplicated Malaria Suspected Tested', gender, age_group });
      if (isPositive) codings.push({ diagnosis: 'Uncomplicated Malaria Tested Positive', gender, age_group });
    } else if (notTested) {
      codings.push({ diagnosis: 'Uncomplicated Malaria not tested but treated as malaria', gender, age_group });
    }
  }
  return codings;
}

// ─────────────────────────────────────────────────────────────────────────────
// CORE AGGREGATION
// ─────────────────────────────────────────────────────────────────────────────
function aggregateVisits(visits) {
  const aggMap = {};
  function tally(diagnosis, gender, age_group) {
    if (!diagnosis) return;
    if (!aggMap[diagnosis]) aggMap[diagnosis] = {};
    const key = `${gender}|${age_group}`;
    aggMap[diagnosis][key] = (aggMap[diagnosis][key] || 0) + 1;
  }
  visits.forEach(v => {
    const gender    = v.gender    || 'Male';
    const age_group = v.age_group || '20-34';
    if (v.provisional_diagnosis) {
      const mc = getMalariaCodings(v);
      if (mc) {
        mc.forEach(c => tally(c.diagnosis, c.gender, c.age_group));
        if (v.additional_diagnosis && v.additional_diagnosis_status === 'new')
          tally(v.additional_diagnosis, gender, age_group);
        return;
      }
    }
    if (v.principal_diagnosis && v.principal_diagnosis_status === 'new')
      tally(v.principal_diagnosis, gender, age_group);
    if (v.additional_diagnosis && v.additional_diagnosis_status === 'new')
      tally(v.additional_diagnosis, gender, age_group);
  });
  return aggMap;
}

// ─────────────────────────────────────────────────────────────────────────────
// ANTIMALARIA RETURNS AGGREGATION
// ACT/Antimalarial detected from medicines_prescribed text
// Microscopy/RDT detected from test_requested field
// ─────────────────────────────────────────────────────────────────────────────
const ACT_KEYWORDS    = ['act','artemether','artesunate','coartem','lumefantrine','amodiaquine','fansidar','sp ','sulphadoxine','pyrimethamine','artequin','lonart','camosunate'];
const ANTIMAL_KEYWORDS = [...ACT_KEYWORDS,'quinine','chloroquine','primaquine','proguanil','mefloquine','doxycycline','halofantrine','lumefantrine'];

function detectFromMeds(text, keywords) {
  if (!text) return false;
  const t = text.toLowerCase();
  return keywords.some(k => t.includes(k));
}

function computeAntimalariaReturns(visits) {
  function isUnder5(v) { return UNDER5.includes(v.age_group); }
  const zero = () => ({ u5: 0, above5: 0 });
  const inc  = (obj, v) => { if (isUnder5(v)) obj.u5++; else obj.above5++; };

  const totals = {
    totalOpdNew:        zero(),
    totalMalariaSusp:   zero(),
    onAntimalarials:    zero(),
    onACTs:             zero(),
    confirmedOnACTs:    zero(),
    testedMicroscopy:   zero(),
    testedRDT:          zero(),
    positiveMicroscopy: zero(),
    positiveRDT:        zero(),
  };

  const EXCLUDE = ['All other Diseases','Re-Attendances','Referrals'];

  visits.forEach(v => {
    const isMalariaProvisional = (v.provisional_diagnosis || '').toLowerCase().includes('malaria');
    const testReq    = (v.test_requested || '').trim().toLowerCase();
    const testResult = (v.test_result    || '').toLowerCase();
    const meds       = (v.medicines_prescribed || '') + ' ' + (v.medicines_dispensed || '');

    const isRDT   = testReq.includes('rdt') || (testReq.includes('rapid') && testReq.includes('malaria'));
    const isMicro = testReq.includes('microscop');
    const isPositive = testResult === 'positive';
    const isNegative = testResult === 'negative';
    const isMalariaTest = (isRDT || isMicro) && testReq !== 'no test requested';
    const isTested   = isMalariaTest && (isPositive || isNegative);

    // Detect ACT and antimalarial from medicines text
    const onACT     = detectFromMeds(meds, ACT_KEYWORDS);
    const onAntimal = detectFromMeds(meds, ANTIMAL_KEYWORDS) || onACT;

    // Row 1: all new standard diagnoses excluding 'All other Diseases', old cases, referrals
    if (v.principal_diagnosis_status === 'new' &&
        !EXCLUDE.includes(v.principal_diagnosis) &&
        (ALL_STANDARD_DX.includes(v.principal_diagnosis) || isMalariaProvisional)) {
      inc(totals.totalOpdNew, v);
    }

    if (!isMalariaProvisional) return;

    // Row 2
    inc(totals.totalMalariaSusp, v);
    // Row 3
    if (onAntimal) inc(totals.onAntimalarials, v);
    // Row 4
    if (onACT) inc(totals.onACTs, v);
    // Row 5
    if (isPositive && onACT) inc(totals.confirmedOnACTs, v);
    // Row 6
    if (isMicro && isTested) inc(totals.testedMicroscopy, v);
    // Row 7
    if (isRDT && isTested) inc(totals.testedRDT, v);
    // Row 8
    if (isMicro && isPositive) inc(totals.positiveMicroscopy, v);
    // Row 9
    if (isRDT && isPositive) inc(totals.positiveRDT, v);
  });

  return totals;
}

// ─────────────────────────────────────────────────────────────────────────────
// API ROUTES
// ─────────────────────────────────────────────────────────────────────────────
app.get('/api/visits', (req, res) => {
  const db = loadDB();
  let visits = db.visits;
  if (req.query.month) visits = visits.filter(v => v.visit_date && v.visit_date.startsWith(req.query.month));
  res.json(visits);
});

app.post('/api/visits', (req, res) => {
  const db = loadDB();
  const visit = { id: db.nextId++, created_at: new Date().toISOString(), ...req.body };
  db.visits.push(visit);
  saveDB(db);
  res.json({ success: true, id: visit.id });
});

app.put('/api/visits/:id', (req, res) => {
  const db = loadDB();
  const idx = db.visits.findIndex(v => v.id == req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  db.visits[idx] = { ...db.visits[idx], ...req.body };
  saveDB(db);
  res.json({ success: true });
});

app.delete('/api/visits/:id', (req, res) => {
  const db = loadDB();
  db.visits = db.visits.filter(v => v.id != req.params.id);
  saveDB(db);
  res.json({ success: true });
});

// Morbidity report (JSON)
app.get('/api/report', (req, res) => {
  const db = loadDB();
  let visits = db.visits;
  if (req.query.month) visits = visits.filter(v => v.visit_date && v.visit_date.startsWith(req.query.month));
  const aggMap = aggregateVisits(visits);
  const report = Object.entries(aggMap).map(([diagnosis, counts]) => {
    const row = { diagnosis };
    let total = 0;
    ['Male','Female'].forEach(g => {
      AGE_GROUPS.forEach(ag => {
        const k = `${g}|${ag}`;
        row[`${g}_${ag}`] = counts[k] || 0;
        total += counts[k] || 0;
      });
    });
    row.total = total;
    return row;
  });
  res.json(report);
});

// Antimalaria returns (JSON)
app.get('/api/antimalaria', (req, res) => {
  const db = loadDB();
  let visits = db.visits;
  if (req.query.month) visits = visits.filter(v => v.visit_date && v.visit_date.startsWith(req.query.month));
  res.json(computeAntimalariaReturns(visits));
});

// Export line list
app.get('/api/export/linelist', (req, res) => {
  const db = loadDB();
  let visits = db.visits;
  if (req.query.month) visits = visits.filter(v => v.visit_date && v.visit_date.startsWith(req.query.month));
  const wb = XLSX.utils.book_new();
  const wsData = visits.map(v => ({
    'Visit ID': v.id,
    'Month/Year': v.visit_date,
    'Age': v.age,
    'Age Group': v.age_group,
    'Gender': v.gender,
    'Pregnant': v.pregnant || '',
    'Provisional Diagnosis': v.provisional_diagnosis || '',
    'Principal Diagnosis': v.principal_diagnosis || '',
    'Diag. Status': v.principal_diagnosis_status,
    'Additional Diagnosis': v.additional_diagnosis || '',
    'Add. Diag. Status': v.additional_diagnosis_status || '',
    'Test Requested': v.test_requested || '',
    'Test Result': v.test_result || '',
    'Test Result Details': v.test_result_detail || '',
    'Medicines Prescribed': v.medicines_prescribed || '',
    'Medicines Dispensed': v.medicines_dispensed || '',
    'Referred': v.referred || '',
    'Re-attendance': v.re_attendance || 'No',
  }));
  const ws = XLSX.utils.json_to_sheet(wsData);
  XLSX.utils.book_append_sheet(wb, ws, 'Line List');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Disposition', `attachment; filename="OPD_LineList_${req.query.month || 'all'}.xlsx"`);
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.send(buf);
});

// Export morbidity report — exact DHIMS2 structure from memory
app.get('/api/export/morbidity', (req, res) => {
  const db = loadDB();
  let visits = db.visits;
  if (req.query.month) visits = visits.filter(v => v.visit_date && v.visit_date.startsWith(req.query.month));
  const aggMap = aggregateVisits(visits);

  // Helper: get count for a diagnosis/gender/age combination
  function cnt(dx, gender, ag) {
    return (aggMap[dx] && aggMap[dx][`${gender}|${ag}`]) || 0;
  }

  // Build header row matching DHIMS2 exactly:
  // Data element | Male <28days ... Male 70+ | Female <28days ... Female 70+ | Male | Female | <28days | 1-11mths | 1-4 | 5-9 | 10-14 | 15-17 | 18-19 | 20-34 | 35-49 | 50-59 | 60-69 | 70+ | Total
  const mCols   = AGE_GROUPS.map(ag => `Male , ${ag}`);
  const fCols   = AGE_GROUPS.map(ag => `Female, ${ag}`);
  const combCols = AGE_GROUPS; // combined age totals
  const header  = ['Data element', ...mCols, ...fCols, 'Male', 'Female', ...combCols, 'Total'];

  const excelRows = [];

  REPORT_STRUCTURE.forEach(section => {
    // Section header row
    excelRows.push([`${section.section} Age Group and Gender for Patients/Morbidity`]);
    excelRows.push(header);

    section.rows.forEach(dx => {
      const row = [dx];
      let mTotal = 0, fTotal = 0;
      const agCombined = {};
      AGE_GROUPS.forEach(ag => { agCombined[ag] = 0; });

      AGE_GROUPS.forEach(ag => {
        const v = cnt(dx, 'Male', ag);
        row.push(v || null);
        mTotal += v;
        agCombined[ag] += v;
      });
      AGE_GROUPS.forEach(ag => {
        const v = cnt(dx, 'Female', ag);
        row.push(v || null);
        fTotal += v;
        agCombined[ag] += v;
      });

      const grand = mTotal + fTotal;
      row.push(mTotal || null);
      row.push(fTotal || null);
      AGE_GROUPS.forEach(ag => row.push(agCombined[ag] || null));
      row.push(grand || null);

      excelRows.push(row);
    });

    excelRows.push([]); // blank separator
  });

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(excelRows);
  ws['!cols'] = [{ wch: 55 }, ...Array(header.length - 1).fill({ wch: 10 })];
  XLSX.utils.book_append_sheet(wb, ws, 'Morbidity Report');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Disposition', `attachment; filename="Morbidity_Report_${req.query.month || 'all'}.xlsx"`);
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.send(buf);
});

// Export antimalaria returns
app.get('/api/export/antimalaria', (req, res) => {
  const db = loadDB();
  let visits = db.visits;
  if (req.query.month) visits = visits.filter(v => v.visit_date && v.visit_date.startsWith(req.query.month));
  const t      = computeAntimalariaReturns(visits);
  const period = req.query.month || 'All';

  const excelRows = [
    ['Monthly Malaria Data Returns on Anti-Malarials', '', '', ''],
    ['Health Facility Monthly Records - Malaria', '', '', ''],
    ['Period:', period, '', ''],
    ['', '', '', ''],
    ['', 'Number', '', ''],
    ['', 'Under five years', '5 years and Above', 'Total'],
    ['Total OPD New cases total from morbidity (excluding all other diseases, old cases, and referrals)', t.totalOpdNew.u5 || null, t.totalOpdNew.above5 || null, (t.totalOpdNew.u5 + t.totalOpdNew.above5) || null],
    ['Total Uncomplicated Malaria Cases Suspected', t.totalMalariaSusp.u5 || null, t.totalMalariaSusp.above5 || null, (t.totalMalariaSusp.u5 + t.totalMalariaSusp.above5) || null],
    ['Number of OPD malaria cases put on Anti-malarials', t.onAntimalarials.u5 || null, t.onAntimalarials.above5 || null, (t.onAntimalarials.u5 + t.onAntimalarials.above5) || null],
    ['Number of OPD malaria cases put on ACTs', t.onACTs.u5 || null, t.onACTs.above5 || null, (t.onACTs.u5 + t.onACTs.above5) || null],
    ['Number of confirmed cases(Tested Positive) put on ACTs', t.confirmedOnACTs.u5 || null, t.confirmedOnACTs.above5 || null, (t.confirmedOnACTs.u5 + t.confirmedOnACTs.above5) || null],
    ['Number of OPD malaria cases tested for malaria parasites using microscopy', t.testedMicroscopy.u5 || null, t.testedMicroscopy.above5 || null, (t.testedMicroscopy.u5 + t.testedMicroscopy.above5) || null],
    ['Number of OPD malaria cases tested for malaria parasites using RDT', t.testedRDT.u5 || null, t.testedRDT.above5 || null, (t.testedRDT.u5 + t.testedRDT.above5) || null],
    ['Number of OPD malaria cases tested positive using microscopy', t.positiveMicroscopy.u5 || null, t.positiveMicroscopy.above5 || null, (t.positiveMicroscopy.u5 + t.positiveMicroscopy.above5) || null],
    ['Number of OPD malaria cases tested positive using RDTs', t.positiveRDT.u5 || null, t.positiveRDT.above5 || null, (t.positiveRDT.u5 + t.positiveRDT.above5) || null],
  ];

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet(excelRows);
  ws['!cols'] = [{ wch: 72 }, { wch: 18 }, { wch: 20 }, { wch: 10 }];
  XLSX.utils.book_append_sheet(wb, ws, 'Antimalaria Returns');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  res.setHeader('Content-Disposition', `attachment; filename="Antimalaria_Returns_${period}.xlsx"`);
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.send(buf);
});

app.listen(PORT, () => {
  console.log(`\n✅ GHS OPD Morbidity System running at http://localhost:${PORT}`);
  console.log(`   Open your browser and navigate to: http://localhost:${PORT}\n`);
});
