# GHS OPD Morbidity System
### Ghana Health Service · Offline Patient Entry & Morbidity Reporting

---

## Technology Stack

| Component | Technology | Why |
|-----------|-----------|-----|
| **Backend** | Node.js + Express | Lightweight, runs offline, fast |
| **Database** | JSON flat-file (morbidity.json) | Zero installation, portable, human-readable, easily backed up |
| **Export** | SheetJS (xlsx) | Generates Excel files compatible with all versions |
| **Frontend** | Vanilla HTML/CSS/JS | No build tools, works in any browser, fast |

> **Why not SQLite/PostgreSQL?** For a single-facility offline tool with one concurrent user, a JSON flat-file is simpler to deploy, requires zero DB installation, and the file can be directly emailed or copied as a backup. For multi-facility or networked use, upgrading to SQLite or PostgreSQL is straightforward.

---

## Requirements

- **Node.js** v16 or newer → https://nodejs.org (choose LTS)
- Any modern browser (Chrome, Firefox, Edge)

---

## Installation (One-Time)

1. Copy the entire `ghsmorbidity` folder to the computer
2. Open a terminal / command prompt in that folder
3. Run: `npm install`
4. Done!

---

## Starting the System

**Windows:** Double-click `start.bat`  
**Mac/Linux:** Run `./start.sh` or `node server.js`

Then open your browser and go to: **http://localhost:3456**

---

## How to Use

### 1. New Entry (Consulting Room Data Capture)
- Click **New Entry** in the sidebar
- Fill in patient details from the Consulting Room Register:
  - Date, OPD Number, Age Group, Gender
  - Principal Diagnosis → select status (New or Old)
  - Additional Diagnosis if applicable
  - Pregnancy status, NHIS, Medicines, Clinician
- Click **Save Entry**

### 2. Line List
- View all captured entries in tabular form
- Filter by month or search by name/diagnosis
- Edit or delete any entry

### 3. Morbidity Report
- Select a month and click **Generate**
- See aggregated counts by diagnosis, age group, and gender
- This mirrors the DHIMS2 Monthly OPD Morbidity form structure

### 4. Export Data
- **Line List** → Excel file with one row per patient visit
- **Morbidity Report** → Excel file with aggregated counts by diagnosis × age × gender, ready for DHIMS2 entry

---

## Data Backup

Your data is stored in `morbidity.json` in the program folder.  
**Back this file up regularly** — copy it to a USB drive or email it to yourself.

To restore: replace the `morbidity.json` file with your backup.

---

## Key Design Decisions

- **New Case vs Old Case**: Only New Cases are counted as individual morbidity entries. Old Cases are counted as Re-attendances — this mirrors the GHS definition.
- **All 110 diagnoses** from the DHIMS2 morbidity form are pre-loaded in the diagnosis dropdown.
- **Age groups** match the GHS/DHIMS2 standard: <28days, 1-11mths, 1-4, 5-9, 10-14, 15-17, 18-19, 20-34, 35-49, 50-59, 60-69, 70+

---

## Support / Customization

To add your facility name to reports, edit the top of `public/index.html`.  
To change the port from 3456, edit the `PORT` variable in `server.js`.
