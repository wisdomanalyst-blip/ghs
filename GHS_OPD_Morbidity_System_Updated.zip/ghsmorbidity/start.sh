#!/bin/bash
echo "========================================"
echo "  GHS OPD Morbidity System"
echo "  Ghana Health Service"
echo "========================================"
echo ""
echo "Starting server..."
node server.js
